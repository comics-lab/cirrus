# Fearless Btrfs RAID1 Recovery — Quick Runbook (2026‑01)

This is a **concise, execution-focused runbook** distilled from a real recovery.
Use this when you need fast guidance without narrative detail.

---

## Scenario
- Btrfs RAID1 filesystem
- One disk failed and is MISSING
- Replacement disk is available (same or larger size)
- Goal: restore redundancy with minimal risk

---

## Immediate Actions (When Failure Detected)

1. **Freeze writes**
   - Stop ingest/download services
   - Consider remounting read-only

2. **Do NOT**
   - Run balance
   - Run scrub
   - Reboot
   - Remove devices blindly

3. **Order replacement disk first**

---

## Replacement Disk Prep

Identify the new disk:
```bash
lsblk -o NAME,SIZE,MODEL,SERIAL,TRAN
```

Wipe vendor signatures (entire disk):
```bash
sudo wipefs -a /dev/sdX
```

---

## Add Replacement Device

```bash
sudo btrfs device add /dev/sdX /mnt/fearless
```

Verify:
```bash
btrfs filesystem show /mnt/fearless
```

Expected:
- 3 devices total
- old disk MISSING
- new disk present with 0 used

---

## Primary Recovery Operation (CRITICAL)

Remove the failed device **by devid**:

```bash
sudo btrfs device remove <DEVID> /mnt/fearless
```

Example:
```bash
sudo btrfs device remove 2 /mnt/fearless
```

### Rules
- This may run **many hours or days**
- **Do NOT interrupt**
- No UI/progress is normal

---

## Monitoring (Safe to Run)

```bash
btrfs filesystem show /mnt/fearless
btrfs device stats /mnt/fearless
btrfs filesystem df /mnt/fearless
```

### Abort ONLY if:
- `read_io_errs` increase on surviving or replacement disk

Ignore:
- Huge error counters on the failed (MISSING) disk

---

## Completion Criteria

Command returns to prompt.

Filesystem should show:
```text
Total devices: 2
/dev/sd(old)
/dev/sd(new)
```
No MISSING devices.

---

## Verification Scrub

```bash
sudo btrfs scrub start -Bd /mnt/fearless
```

Expected:
- 0 uncorrectable errors

---

## After Recovery

- Physically remove or retire failed disk
- Resume services gradually
- Document the incident
- Do NOT rebalance immediately

---

## Key Lessons

- Time ≠ failure
- Do nothing > panic
- Only healthy disk errors matter
- Btrfs is loud when healthy

---

**End of Runbook**

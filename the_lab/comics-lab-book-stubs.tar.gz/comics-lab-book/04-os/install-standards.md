# OS Install Standards


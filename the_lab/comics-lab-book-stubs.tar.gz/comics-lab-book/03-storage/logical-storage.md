# Logical Storage Model


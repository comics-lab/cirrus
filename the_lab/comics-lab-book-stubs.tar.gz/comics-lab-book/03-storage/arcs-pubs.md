# arcs / pubs Strategy


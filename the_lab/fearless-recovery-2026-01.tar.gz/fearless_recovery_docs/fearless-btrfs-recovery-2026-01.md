# Fearless Btrfs RAID1 Recovery — January 2026

## Overview

This document captures the full recovery of the **Fearless** Btrfs RAID1 filesystem
after the failure of one 14TB USB disk. The recovery involved replacing the failed
device with a larger 18TB disk and allowing Btrfs to relocate all data safely.

The process took multiple days and required patience, careful interpretation of
Btrfs behavior, and strict avoidance of premature intervention.

This document is derived from a live recovery session and preserves the **reasoning
and decision-making**, not just the commands.

---

## System Context

- Host: **The Beast**
- Filesystem: **Btrfs RAID1**
- Mountpoint: `/mnt/fearless`
- Original devices:
  - `/dev/sde` — 14TB (healthy survivor)
  - `/dev/sdf` — 14TB (**failed**)
- Replacement device:
  - `/dev/sdj` — 18TB (new)

---

## Initial Condition

Filesystem observed in a degraded state:

```
Label: 'fearless'
Total devices 2
/dev/sde    present
/dev/sdf    MISSING
```

Actions taken immediately:
- Filesystem mounted read-only
- All write-heavy services stopped
- No rebalance or scrub attempted
- Replacement disk ordered before any destructive action

---

## Replacement Disk Preparation

New disk identified:

```bash
lsblk -o NAME,SIZE,MODEL,SERIAL,TRAN
```

Result:
- `/dev/sdj` — ~18.2TB USB disk

Factory partitioning removed:

```bash
sudo wipefs -a /dev/sdj
```

---

## Adding the Replacement Device

The new device was added to the filesystem:

```bash
sudo btrfs device add /dev/sdj /mnt/fearless
```

Filesystem state immediately after:

```text
Total devices 3
/dev/sde    used ~12TB
/dev/sdf    MISSING
/dev/sdj    used 0
```

At this stage:
- No balance was running
- No data had been relocated yet
- Filesystem was writable

---

## Device Removal (Primary Recovery Operation)

The failed device was removed by **device ID**, not by path:

```bash
sudo btrfs device remove 2 /mnt/fearless
```

Important notes:
- This command **ran for many hours (multi-day)**
- It must NOT be interrupted
- It performs data and metadata relocation internally
- Progress is not linear and offers no UI feedback

---

## Monitoring During Device Removal

### Key health checks (run periodically)

```bash
sudo btrfs filesystem show /mnt/fearless
sudo btrfs device stats /mnt/fearless
sudo btrfs filesystem df /mnt/fearless
```

### Critical rule

- **ONLY read errors on `/dev/sde` or `/dev/sdj` matter**
- Massive error counts on `/dev/sdf` are expected and irrelevant

Example ghost counter (near uint64 max):

```text
/dev/sdf write_io_errs 18446744072934949933
```

This is a counter wrap / artifact and not real damage.

---

## Evidence of Progress

During the operation, data usage migrated steadily:

```text
/dev/sdj used:
- ~3.6 TiB → ~8.9 TiB → ~9.9 TiB → ~12.16 TiB
```

Corresponding decrease on `/dev/sde` confirmed relocation.

---

## Completion of Device Removal

Completion time:

- **Thursday, January 22, 2026 — 04:32 AM**

Final filesystem topology:

```text
Total devices 2
/dev/sde 12.73TiB used 12.16TiB
/dev/sdj 18.19TiB used 12.16TiB
```

No missing devices.
No errors on active disks.

---

## Post-Recovery Verification

### Device stats (clean)

```text
/dev/sde: all error counters 0
/dev/sdj: all error counters 0
```

### Allocation profiles

```text
Data, RAID1
Metadata, RAID1
System, RAID1
GlobalReserve intact
```

This confirms:
- The survivor disk lived through the rebuild cleanly
- The new disk is healthy
- USB path is stable

---

## Scrub (Final Integrity Check)

Scrub initiated:

```bash
sudo btrfs scrub start -Bd /mnt/fearless
```

Scrub status (early):

```text
Total to scrub: 24.26TiB
Rate: ~484 MiB/s
Errors: none
ETA ~19:18
```

Scrub confirms:
- Both mirrors readable
- Checksums valid
- No silent corruption

---

## Observations & Lessons Learned

### 1. Time Expectations
- Large Btrfs `device remove` over USB can take many hours to days
- Duration alone is NOT an indicator of failure

### 2. Error Interpretation
- Huge error counters on a missing disk are normal
- Only surviving and replacement disks matter

### 3. Do Not Interrupt
- Ctrl-C, reboot, or unmount during `device remove` risks corruption
- Doing nothing is often the safest action

### 4. Extra Space on Larger Replacement Disk
- Btrfs RAID1 usable capacity = smallest device
- Extra space cannot be used for cache, metadata, or acceleration
- This is by design

---

## Final Status

- Filesystem: **Healthy**
- Redundancy: **Restored**
- Data integrity: **Verified**
- Services: Safe to resume after scrub completion

**Fearless lived up to its name.**

---

## Commands Reference (Quick)

```bash
# Show filesystem topology
btrfs filesystem show /mnt/fearless

# Device stats
btrfs device stats /mnt/fearless

# Allocation details
btrfs filesystem df /mnt/fearless

# Start scrub
btrfs scrub start -Bd /mnt/fearless

# Scrub status
btrfs scrub status /mnt/fearless
```

---

*End of recovery record.*
